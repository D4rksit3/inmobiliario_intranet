<?php
require_once __DIR__ . '/../app/core/Router.php';

$url = isset($_GET['url']) ? explode('/', filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL)) : [];

Router::route($url);
