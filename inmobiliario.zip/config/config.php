<?php

define('BASE_URL', 'http://localhost/public/');

return [
    'db' => [
        'host' => 'localhost',
        'user' => 'root',
        'pass' => '',
        'name' => 'inmobiliario'
    ]
];
